package com.bankingsystem.entity.enums;

public enum RequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}


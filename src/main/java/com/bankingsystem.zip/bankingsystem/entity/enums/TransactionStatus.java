package com.bankingsystem.entity.enums;

public enum TransactionStatus {
    PENDING,
    APPROVED,
    REJECTED,
    SUCCESS
}
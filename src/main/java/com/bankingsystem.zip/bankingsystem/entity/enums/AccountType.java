package com.bankingsystem.entity.enums;

public enum AccountType {
    SAVINGS,
    CURRENT
}

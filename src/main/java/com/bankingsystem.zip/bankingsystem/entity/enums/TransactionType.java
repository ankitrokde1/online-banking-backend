package com.bankingsystem.entity.enums;

public enum TransactionType {
    DEPOSIT,
    WITHDRAW,
    TRANSFER
}

package com.bankingsystem.exception;

public class ResetTokenInvalidException extends RuntimeException {
    public ResetTokenInvalidException(String message) {
        super(message);
    }
}

